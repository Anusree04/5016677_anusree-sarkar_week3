@GetMapping
public Page<Employee> getAllEmployees(@RequestParam(defaultValue = "0") int page, 
                                      @RequestParam(defaultValue = "10") int size, 
                                      @RequestParam(defaultValue = "id") String sort) {
    Pageable pageable = PageRequest.of(page, size, Sort.by(sort));
    return employeeRepository.findAll(pageable);
}