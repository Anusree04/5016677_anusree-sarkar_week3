public interface DepartmentRepository extends JpaRepository<Department, Long> {
    List<Department> findByName(String name);
}