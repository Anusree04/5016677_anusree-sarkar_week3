@GetMapping("/projections")
public List<EmployeeProjection> getAllEmployeesProjected() {
    return employeeRepository.findAllProjectedBy();
}