public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    List<Employee> findByName(String name);
    List<Employee> findByDepartmentName(String departmentName);
    @Query("SELECT e FROM Employee e WHERE e.email LIKE %:email%")
    List<Employee> findByEmailLike(@Param("email") String email);
    
    Page<Employee> findAll(Pageable pageable);
}